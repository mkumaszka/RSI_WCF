﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;
using WcfServiceContract;

namespace WcfServiceHost_V2
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost mojHost = new ServiceHost(typeof(MyCalculator));
            try
            {

                ServiceEndpoint endpoint1 = mojHost.Description.Endpoints.Find(typeof(ICalculator));
                ServiceEndpoint endpoint2 = mojHost.Description.Endpoints.Find(new Uri("http://localhost:10001/Calculator/endpoint2"));
                ServiceEndpoint endpoint3 = mojHost.Description.Endpoints.Find(new Uri("http://localhost:10002/Calculator/endpoint3"));
                Uri address4 = new Uri("net.tcp://localhost:30000/MyServiceTCP");
                ServiceEndpoint endpoint4 = mojHost.AddServiceEndpoint(typeof(ICalculator),
                new NetTcpBinding(),
                 address4);
                //wyswietl endpointy
                Console.WriteLine("\n---> Endpointy:");

                ShowEndpoint(endpoint1);
                ShowEndpoint(endpoint2);
                ShowEndpoint(endpoint3);
                ShowEndpoint(endpoint4);

                mojHost.Open();
                Console.WriteLine("\n--> Serwis 1 jest uruchomiony.");

                ContractDescription cd =
                ContractDescription.GetContract(typeof(ICalculator));
                Console.WriteLine("Informacje o kontrakcie:");
                Type contractType = cd.ContractType;
                Console.WriteLine("\tContract type: {0}", contractType.ToString());
                string name = cd.Name;
                Console.WriteLine("\tName: {0}", name);
                OperationDescriptionCollection odc = cd.Operations;
                Console.WriteLine("\tOperacje:");
                foreach (OperationDescription od in odc) {
                    Console.WriteLine("\t\t" + od.Name);
                } 

                Console.WriteLine("\n--> Nacisnij <ENTER> aby zakonczyc.");
                Console.WriteLine();
                Console.ReadLine();
                mojHost.Close();
            }
            catch (CommunicationException ce)
            {
                Console.WriteLine("Wystapil wyjatek: {0}", ce.Message);
                mojHost.Abort();
            }
        }

        static void ShowEndpoint(ServiceEndpoint endpoint)
        {
            Console.WriteLine("\nService endpoint {0}:", endpoint.Name);
            Console.WriteLine("Binding: {0}", endpoint.Binding.ToString());
            Console.WriteLine("ListenUri: {0}", endpoint.ListenUri.ToString());
        }
    }
}
