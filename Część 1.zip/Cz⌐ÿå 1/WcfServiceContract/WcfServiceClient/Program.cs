﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WcfServiceClient.ServiceReferenceCalculator;

namespace WcfServiceClient
{
    class Program
    {
        static void Main(string[] args)
        {
            //Krok 1: Utworzenie instancji WCF proxy.
            CalculatorClient mojKlient = new CalculatorClient();
            // Krok 2: Wywolanie operacji uslugi.

            double value1 = 40;
            double value2 = 10;
            String values = value1 + " i " + value2 + ": ";

            // Operacja Dodaj:
            double result = mojKlient.Dodaj(value1, value2);
            Console.WriteLine("Dodaj " + values + result);
            // Operacja Odejmij:

            result = mojKlient.Odejmij(value1, value2);
            Console.WriteLine("Odejmij " + values + result);
            // Operacja Pomnoz:
            result = mojKlient.Pomnoz(value1, value2);
            Console.WriteLine("Pomnoz " + values + result);
            // Operacja Podziel:
            result = mojKlient.Podziel(value1, value2);
            Console.WriteLine("Podziel " + values + result);
            // Krok 3: Zamknięcie klienta zamyka polaczenie i czysci zasoby.
            mojKlient.Close();
        }
    }
}
