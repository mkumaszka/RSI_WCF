﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WcfServiceClient_V2.ServiceReference1;

namespace WcfServiceClient_V2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Krok 1: Utworzenie instancji WCF proxy.
            CalculatorClient client1 = new CalculatorClient("WSHttpBinding_ICalculator");
            CalculatorClient client2 = new CalculatorClient("mojEndpoint2");
            CalculatorClient client3 = new CalculatorClient("mojEndpoint3");
            CalculatorClient client4 = new CalculatorClient("NetTcpBinding_ICalculator");

            // Wykonanie zadań na kliencie
            ExecuteClient(client1);
            ExecuteClient(client2);
            ExecuteClient(client3);
            ExecuteClient(client4);

            Console.ReadLine();
        }

        static void ExecuteClient(CalculatorClient client)
        {
            double value1 = 40;
            double value2 = 10;

            // Operacja Dodaj:
            double result = client.Dodaj(value1, value2);
            Console.WriteLine("Dodaj: " + result);
            // Operacja Odejmij:

            result = client.Odejmij(value1, value2);
            Console.WriteLine("Odejmij: " + result);
            // Operacja Pomnoz:
            result = client.Pomnoz(value1, value2);
            Console.WriteLine("Pomnoz: " + result);
            // Operacja Podziel:
            result = client.Podziel(value1, value2);
            Console.WriteLine("Podziel: " + result);
            // Operacja Sumuj:
            result = client.Sumuj(value1);
            Console.WriteLine("Sumuj: " + result);
            Console.WriteLine();

            // Krok 3: Zamknięcie klienta zamyka polaczenie i czysci zasoby.
            client.Close();
        }
    }
}
