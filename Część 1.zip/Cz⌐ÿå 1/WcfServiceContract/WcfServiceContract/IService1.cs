﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WcfServiceContract
{
    [ServiceContract]
    public interface ICalculator
    {
        [OperationContract]
        double Dodaj(double n1, double n2);

        [OperationContract]
        double Odejmij(double n1, double n2);

        [OperationContract]
        double Pomnoz(double n1, double n2);

        [OperationContract]
        double Podziel(double n1, double n2);

        [OperationContract]
        double Sumuj(double n1);
    }
}