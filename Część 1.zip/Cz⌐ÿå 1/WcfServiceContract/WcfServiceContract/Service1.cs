﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WcfServiceContract
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class MyCalculator : ICalculator
    {
        double suma = 0;

        public double Dodaj(double n1, double n2)
        {
            return n1 + n2;
        }

        public double Odejmij(double n1, double n2)
        {
            return n1 - n2;
        }

        public double Pomnoz(double n1, double n2)
        {
            return n1 * n2;
        }

        public double Podziel(double n1, double n2)
        {
            return n1 / n2;
        }

        public double Sumuj(double n1)
        {
            suma += n1;
            return suma;
        }
    }
}
