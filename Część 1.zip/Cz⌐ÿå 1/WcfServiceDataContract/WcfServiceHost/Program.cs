﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;
using WcfServiceDataContract;

namespace WcfServiceHost
{
    class Program
    {
        static void Main(string[] args)
        {
            Uri baseAddress1 = new Uri("http://localhost:10001/Calculator");
            ServiceHost mojHost1 = new ServiceHost(typeof(MyCalculatorLZ) ,baseAddress1);
            try
            {
                ServiceEndpoint endpoint1 = mojHost1.AddServiceEndpoint(typeof(IKalkulatorLZ), new WSHttpBinding(), "endpoint1");
                ServiceMetadataBehavior smb = new ServiceMetadataBehavior();
                // Metadane:
                smb.HttpGetEnabled = true;
                mojHost1.Description.Behaviors.Add(smb);
                mojHost1.Open();
                Console.WriteLine("--->KalkulatorLZ jest uruchomiony.");
                Console.WriteLine("--->Nacisnij <ENTER> aby zakonczyc.\n");
                Console.ReadLine(); //czekam na zamkniecie
                mojHost1.Close();
                Console.WriteLine("---> Serwis zakonczyl dzialanie.");
            }
            catch (CommunicationException ce)
            {
                Console.WriteLine("Wystapil wyjatek: {0}", ce.Message);
                mojHost1.Abort();
            }
        }
    }
}
