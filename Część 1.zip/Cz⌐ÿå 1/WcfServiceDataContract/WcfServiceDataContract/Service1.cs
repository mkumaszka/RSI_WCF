﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WcfServiceDataContract
{
    public class MyCalculatorLZ : IKalkulatorLZ
    {
        public LiczbaZ DodajLZ(LiczbaZ n1, LiczbaZ n2)
        {
            Console.WriteLine("...wywolano DodajLZ(...)");
            return new LiczbaZ(n1.czescR + n2.czescR,
            n1.czescU + n2.czescU);
        }
    }
}
